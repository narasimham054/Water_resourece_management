#ifndef __LCD_5110_H
#define __LCD_5110_H

#include "main.h"
void LCD5110_init();
void LCD5110_clear();
void LCD5110_Write_Dec(unsigned int );
void LCD5110_write_string(unsigned char*);
void LCD5110_write_char(unsigned char );
void LCD5110_LCD_write_byte(unsigned char , unsigned char );
void LCD5110_CS(unsigned char);
void LCD5110_SCK(unsigned char);
void LCD5110_DIN(unsigned char);
void LCD5110_DC(unsigned char );
void LCD5110_Led(unsigned char);
void LCD5110_RST(unsigned char);
void LCD5110_set_XY(unsigned char ,unsigned char );

#endif
